# Your repo!

This is your git repository for the 2019-20 ATCS class at Menlo School!

As a reminder, here are the most frequently used git commands:

* git status
* git add *
* git commit -m "Your commit message here"
* git push
